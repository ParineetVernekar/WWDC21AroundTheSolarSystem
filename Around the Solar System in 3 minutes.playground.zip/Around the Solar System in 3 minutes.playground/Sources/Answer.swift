import Foundation

public struct Answer : Hashable{    
    public let answer : String
    public let isTrue : Bool
    
    public init(answer: String, isTrue: Bool) {
        self.answer = answer
        self.isTrue = isTrue
    }
}
