
import SwiftUI
import SceneKit
import PlaygroundSupport

@available(iOS 13.0, *)
public struct NextButtonView: View {
    
    var personalisedQuestions : [Question]{
        if let clickedPlanets = UserDefaults.standard.value(forKey: "clickedPlanets") as? [String]{
            var array : [Question] = []
            for planet in clickedPlanets{
                let planetArray = questions.filter{ $0.topic == planet }
                array.append(contentsOf: planetArray)
            }
            return array
        } else{
            let noOfQuestions = Int.random(in: 1...8)
            let defaultQuestions = Array(questions.prefix(noOfQuestions))
            return defaultQuestions
        }
    }
    
    public var body: some View {
        VStack{
            Text("Learnt about enough planets? Well, I guess you're ready for the Quiz then! Click the Quiz button to go to Level 2 - Solidify. Or, go to the 'Quiz' page to add your own questions!")
            Button(action: {
                PlaygroundPage.current.navigateTo(page: .pageReference(reference: "Quiz"))
            }) {
                Text("Level 2 - Solidify")
                    .padding()
            }
            
        }
        .frame(width: .infinity, height: .infinity, alignment: .center)
        .background(Color.init(red: 0.91, green: 0.97, blue: 0.93))
        .ignoresSafeArea()
    }
    
    
    public init(){}
}

@available(iOS 13.0, *)
public struct NextButtonView_previews: PreviewProvider {
    public static var previews: some View {
        NextButtonView()
    }
}
