
import Foundation
import SceneKit

public struct Planet{
    internal init(radius: CGFloat, position: SCNVector3, nodeName: String, textNodeName: String, textPosition: SCNVector3, textScale: SCNVector3, displayedName: String, imgName: String, planetImgName: String, planetImgCaption: String, information: String, facts: [String]) {
        self.radius = radius
        self.position = position
        self.nodeName = nodeName
        self.textNodeName = textNodeName
        self.textPosition = textPosition
        self.textScale = textScale
        self.displayedName = displayedName
        self.imgName = imgName
        self.planetImgName = planetImgName
        self.planetImgCaption = planetImgCaption
        self.information = information
        self.facts = facts
    }
    
    public var radius : CGFloat
    public var position : SCNVector3
    public var nodeName : String
    
    public var textNodeName : String
    public var textPosition : SCNVector3
    public var textScale : SCNVector3

    public var displayedName : String
    public var imgName : String
    public var planetImgName : String
    public var planetImgCaption : String

    public var information : String
    public var facts : [String]


}
