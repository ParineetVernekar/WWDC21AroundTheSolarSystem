import Foundation
import SwiftUI
import PlaygroundSupport

public struct IntroView: View{
    @State private var percentage: CGFloat = .zero
    
    public var body: some View {
        ZStack {
            PlanetPath()
                .stroke(Color.gray, style: StrokeStyle(lineWidth: 2, dash: [5]))
            VStack {
                Spacer()
                HStack {
                    Button(action: {
                            PlaygroundPage.current.navigateTo(page: .pageReference(reference: "AR"))
                        
                    }) {
                        Image(uiImage: (UIImage(named: "ceres.jpg") ?? UIImage(systemName: "moon.stars")!))
                            .frame(width: 75, height: 75, alignment: .center)
                            .clipShape(Circle())
                            .aspectRatio(contentMode: .fill)
                            .overlay(
                                Text("Level 1")
                                    .foregroundColor(.black)
                            )
                            .padding()
                    }
                    Spacer()
                }
                Spacer()
                HStack {
                    Spacer()
                    Button(action: {

                        PlaygroundPage.current.navigateTo(page: .pageReference(reference: "Explore"))

                    }) {
                        Image(uiImage: (UIImage(named: "makemake.jpg") ?? UIImage(systemName: "moon.stars")!))
                            .frame(width: 75, height: 75, alignment: .center)
                            .clipShape(Circle())
                            .aspectRatio(contentMode: .fill)
                            .overlay(
                                Text("Level 3")
                                    .foregroundColor(.black)
                            )
                            .padding()
                    }
                }
                Spacer()
                Button(action: {
                    PlaygroundPage.current.navigateTo(page: .pageReference(reference: "Quiz"))
                }) {
                    Image(uiImage: (UIImage(named: "eris.jpg") ?? UIImage(systemName: "moon.stars")!))
                        .frame(width: 75, height: 75, alignment: .center)
                        .clipShape(Circle())
                        .aspectRatio(contentMode: .fill)
                        .overlay(
                            Text("Level 2")
                                .foregroundColor(.black)
                        )
                }
                Spacer()
            }
//            RocketPath()
//                .trim(from: 0, to: percentage) // << breaks path by parts, animatable
//                .stroke(Color.red, style: StrokeStyle(lineWidth: 5, lineCap: .round, lineJoin: .round))
//                .animation(.easeOut(duration: 2.0)) // << animate
//                .onAppear {
//                    self.percentage = 1.0 // << activates animation for 0 to the end
//                }
        }
        .background(
            Image(uiImage: (UIImage(named: "stars.jpg") ?? UIImage(systemName: "moon.stars")!))
        )
        .frame(width: 300, height: 500)
        .cornerRadius(25)
        
    }
    
    public init(){}
}
