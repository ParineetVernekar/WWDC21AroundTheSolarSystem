import PlaygroundSupport

/*:
 # AR Learning - Level 1
 This page is all about learning about each planet. Run the code, find some clear space, and explore the universe - from your screen! Tap the planet you're most interesting in to learn more about, and be sure to read the information - there's a quiz later on!
 */

/*:
  - Note:
   During my testing, which was on an 4th Generation iPad Air, I noticed that Swift Playgrounds wouldn't run while 'Enable results' was set to true. Please turn off 'Enable Results' for all pages, so that the playground runs smoothly
 */
PlaygroundPage.current.liveView = ARViewController()
PlaygroundPage.current.needsIndefiniteExecution = true

//: [Level 2 - Quiz](@next)
