import PlaygroundSupport
import Foundation

/*:
 # Quiz - Level 2
 Alright, now it's time for the quiz! Run the code, and get ready for 3 questions on the planet that you selected!
 I used UserDefaults to store the planets you clicked on, then procured questions specifically on those planets, to make sure the quiz was fair
 */

/*:
  - Note:
   During my testing, which was on an 4th Generation iPad Air, I noticed that Swift Playgrounds wouldn't run while 'Enable results' was set to true. Please turn off 'Enable Results' for all pages, so that the playground runs smoothly
 */

//: What's this you ask? This is the code I use to create the quiz questions. By storing the planets you learned about in UserDefaults, I create an array of questions based on those planets. If you didn't learn about any, it takes a random selection from all 27 questions instead.
var personalisedQuestions : [Question]{
    if let clickedPlanets = UserDefaults.standard.value(forKey: "clickedPlanets") as? [String]{
        var array : [Question] = []
        for planet in clickedPlanets{
            let planetArray = questions.filter{ $0.topic == planet }
            array.append(contentsOf: planetArray)
        }
        return array
    } else{
        let noOfQuestions = Int.random(in: 1...8)
        let defaultQuestions = Array(questions.prefix(noOfQuestions))
        return defaultQuestions
    }
}



PlaygroundPage.current.setLiveView(QuizView(quizQuestions: personalisedQuestions))
PlaygroundPage.current.needsIndefiniteExecution = true

//: [Level 3 - Explore](@next)
