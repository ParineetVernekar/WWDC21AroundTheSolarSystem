import PlaygroundSupport

/*:
 # Explore - Level 3
 Congratulations! You've completed your learning, and the quiz - I hope you did well! Now, it's time to explore! Type in a name for your planet, select a texture, and decide if you want it in AR or as an image. Lo and behold - your very own planet!
 */

/*:
  - Note:
   During my testing, which was on an 4th Generation iPad Air, I noticed that Swift Playgrounds wouldn't run while 'Enable results' was set to true. Please turn off 'Enable Results' for all pages, so that the playground runs smoothly
 */

PlaygroundPage.current.setLiveView(ExploreView())
